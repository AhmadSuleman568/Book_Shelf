import  java.awt.*;
import  java.awt.event.*;
import  javax.swing.*;
import  javax.swing.ImageIcon;
import  java.io.*;
import  java.awt.Image;     // for image
import  java.util.Date;    //for date  package
import  java.sql.*;     //for database
import javax.swing.table.DefaultTableModel;
public class Main{
public static void main(String args[])
{



		 
	  JFrame frame2=new JFrame ("BOOK SHELF");
   	  frame2.setLayout(null);
      frame2.setSize(1200,652);
      frame2.setExtendedState(JFrame.MAXIMIZED_BOTH);     // for full screen frame
	  frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     


  // make  a label    
      JLabel  label2=new  JLabel("BOOK SHELF");
      label2.setFont(label2.getFont().deriveFont(37.0f) );
	  label2.setForeground(Color.red);
      label2.setBounds(230, 0, 1200,50);      
	  frame2.add(label2);   // add in frame




//change bounds of search interchange create
 //Make a Button for Create account
       JButton createbutton = new JButton("Add Book");
       createbutton.setBounds(450,350,400,50);
	   createbutton.addActionListener(new Create(frame2) );
	   frame2.add(createbutton);
      
 
  //Make a Button for Modify account
      JButton modifybutton = new JButton("Barrow Books");
      modifybutton.setBounds(450,250,400,50);
	  modifybutton.addActionListener(new Modify(frame2) ); 
	  frame2.add(modifybutton);
  


   //Make a Button for Search ISBN
      JButton searchbutton = new JButton("Search ISBN");
      searchbutton.setBounds(450,150,400,50);
	  searchbutton.addActionListener(new Search(frame2) );	  
	  frame2.add(searchbutton);
 
 
 
   //Make a Button for Search Author
      JButton searchAuthor = new JButton("Search Author");
      searchAuthor.setBounds(450,450,400,50);
	  searchAuthor.addActionListener(new SearchAuthor(frame2) );	  
	  frame2.add(searchAuthor);


 
   //Make a Button for Search Title
      JButton searchTitle = new JButton("Search Title");
      searchTitle.setBounds(450,530,400,50);
	  searchTitle.addActionListener(new SearchTitle(frame2) );	  
	  frame2.add(searchTitle);
	
	
	
	
   //Make a Button for Book Listing
      JButton BookListing = new JButton("Book Listing");
      BookListing.setBounds(450,630,400,50);
	  BookListing.addActionListener(new BookListing(frame2) );	  
	  frame2.add(BookListing);
	   frame2.setVisible(true);

}  //end of main class
//end class
}




 
 
 
 
 
 
 
 
 //start class
 //class for create button
 class Create  implements  ActionListener{

	JFrame  frame2;
	
	// for ist frame
	Create(JFrame frame2)
	{
		this.frame2=frame2;
	}

   
   // for 2nd frame  implements
	 public void actionPerformed(ActionEvent ae)
       {
             JButton create=(JButton)ae.getSource();
			 String createbutton=create.getText();
                    if(createbutton=="Add Book")
	          			{
                          frame2.setVisible(false);     // c0lse frame
					   
					   
     JFrame frame3=new JFrame ("Book Shelf");
   	             frame3.setLayout(null);
                 frame3.setSize(1200,652);
                 frame3.setExtendedState(JFrame.MAXIMIZED_BOTH);     // for full screen frame
	             frame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     
	

  // make  a label    
      JLabel  label3=new  JLabel(" BOOK SHELF ");
      label3.setFont(label3.getFont().deriveFont(37.0f) );
	  label3.setForeground(Color.red);
      label3.setBounds(230, 0, 1200,50);
       //set font 
	  frame3.add(label3);   // add in frame 


	  
	
	// first
		//make a label of ist   
      JLabel  ISBN=new  JLabel("ISBN");
      ISBN.setFont(ISBN.getFont().deriveFont(27.0f) );
      ISBN.setBounds(180,150,330,30);
	  //Font design
	  frame3.add(ISBN);   // add in frame 
	//Make a Textfield 1
     JTextField textISBN= new JTextField();
	 textISBN.setBounds(380,150,330,30);
     frame3.add(textISBN);

   
   //2nd
		//make a label of 2nd   
      JLabel  Author=new  JLabel("Author");
      Author.setFont(Author.getFont().deriveFont(27.0f) );
      Author.setBounds(180,220,330,30);
	  //Font design
	  frame3.add(Author);   // add in frame
	//Make a Textfield 2
     JTextField textAuthor= new JTextField();
	 textAuthor.setBounds(380,230,330,30);
     frame3.add(textAuthor);
   
   
   //3rd
		//make a label of 3rd   
      JLabel  Title=new  JLabel("Title");
      Title.setFont(Title.getFont().deriveFont(27.0f) );
      Title.setBounds(180,290,330,30);
	  //Font design
	  frame3.add(Title);   // add in frame 
	//Make a Textfield 3
     JTextField textTitle= new JTextField();
	 textTitle.setBounds(380,290,330,30);
     frame3.add(textTitle);
   
 

 //4rd
		//make a label of 4rd   
      JLabel  Price=new  JLabel("Price");
      Price.setFont(Price.getFont().deriveFont(27.0f) );
      Price.setBounds(180,360,330,30);
	  //Font design
	  frame3.add(Price);   // add in frame 
	//Make a Textfield 4
     JTextField textPrice= new JTextField();
	 textPrice.setBounds(380,360,330,30);
     frame3.add(textPrice);
   
 

   //5rd
		//make a label of 5rd   
      JLabel  NOcopies=new  JLabel("NOcopies");
      NOcopies.setFont(NOcopies.getFont().deriveFont(27.0f) );
      NOcopies.setBounds(180,430,330,30);
	  //Font design
	  frame3.add(NOcopies);   // add in frame 
	//Make a Textfield 5
     JTextField textNOcopies= new JTextField();
	 textNOcopies.setBounds(380,430,330,30);
     frame3.add(textNOcopies);
    
	
 
      //textarea
   JTextArea textarea=new JTextArea();
   textarea.setBounds(800,150,420,400);
    textarea.setEditable(false);   //for unedit textarea
    frame3.add(textarea);
	
  
 
  // make button for save the account
      JButton save = new JButton("SAVE");
      save.setBounds(550,500,170,50);
	  //Font design
	  save.addActionListener(new action1(textISBN,textAuthor,textTitle,textPrice,textNOcopies,textarea,save) );
	  frame3.add(save);
  
  

// make button for back the menu
      JButton back = new JButton("BACK");
      back.setBounds(250,500,170,50);
	  back.addActionListener(new Creat(frame2,frame3) );   //second and third frame
	 
	  frame3.add(back);
	  
	  
  frame3.setVisible(true);

 
				} //end if 
	   }
 }  //end class   	   
 //end third frame          



//start
// for back button implement
class Creat implements ActionListener{
          
		    JFrame frame2;
			JFrame frame3;
			
    Creat(JFrame frame2,JFrame frame3)
	 {
		this.frame2=frame2;
		this.frame3=frame3;
		
        }
	
		
 public void actionPerformed(ActionEvent ae)
       {
    JButton back=(JButton)ae.getSource();
  String temp=back.getText();
     if(temp=="BACK")
     {
		 frame3.setVisible(false);  //close third frame
	     frame2.setVisible(true);    //open second frame 	  
	   }
 		
	}
} 
//end class


//start class  
 //class for create button of data base
 class action1  implements  ActionListener{

//fields
    JTextArea   textarea;     
	JTextField  textISBN;
	JTextField  textAuthor;
    JTextField  textTitle;
    JTextField  textPrice;
    JTextField  textNOcopies;

	
 	JButton save;
	//variables
	static Connection connection=null;
	static Statement statement=null;
	static ResultSet resultSet=null;
	

   action1(JTextField  textISBN, JTextField  textAuthor, JTextField  textTitle, JTextField  textPrice, JTextField  textNOcopies,JTextArea textarea,JButton save)
              
	 {
		this.textISBN=textISBN;
        this.textAuthor=textAuthor;
	    this.textTitle=textTitle;
	    this.textPrice=textPrice;
	    this.textNOcopies=textNOcopies;
		this.textarea=textarea;
		this.save=save;
		}
		
 public void actionPerformed(ActionEvent ae)
       {


		   //convert text in to string
		     String ISBN=textISBN.getText();
             String Author=textAuthor.getText();
             String Title=textTitle.getText();
             String Price=textPrice.getText();
             String NOcopies=textNOcopies.getText();
          
 Date date = new Date();
	  String tempdate=date + "";
	  		  
			 
			 int xz=Integer.parseInt(ISBN);
			 Long z=Long.valueOf(xz); 
		  
			
			 JButton save=(JButton)ae.getSource();
			 String createbutton=save.getText();

 

//connect to database for connection to create                   
				    if(createbutton=="SAVE")
	          			{
		     try{	
          	Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		  String db="Account.accdb";
			String dbURL="jdbc:ucanaccess://"+db;
			connection=DriverManager.getConnection(dbURL);
			statement=connection.createStatement();
			resultSet=statement.executeQuery("SELECT * FROM Account");
// int x=statement.executeUpdate("INSERT INTO Account VALUES(0,' "+textISBN.getText()+" ',' "+Author+" ',' "+Title+" ',' "+Price+" ',' "+NOcopies+" ')");
   int x=statement.executeUpdate("INSERT INTO Account VALUES(0,' "+z+" ',' "+Author+" ',' "+Title+" ',' "+Price+" ',' "+NOcopies+" ',' "+tempdate+" ')");
    
	   if(x > 0)     
		{			
             JOptionPane.showMessageDialog(save,"Successfully Inserted.");
            System.out.println("Successfully Inserted");             
		}
        
		else            
			{
				                       JOptionPane.showMessageDialog(save,"Insert Failed.");
                System.out.println("Insert Failed."); 
			}
	      } // end try
    
	catch(Exception dil)
         { 
       dil.printStackTrace();
           }   //end catch
		finally{
			try{
				if(null != connection)
				{
                    resultSet.close();
					statement.close();
					connection.close();
                    	} //if
			}  //end try
			catch(SQLException dil2)
                                             {
                                                 dil2.printStackTrace();
                                              } // end catch

		} //end finally
		
						
// write in text
 textarea.setText("ISBN   :"+"    "+ISBN +"\n" +"Author   :"+"    "+Author+"\n"+"Price   :" +"    "+Price+"\n"+"Title  :"+"    "+Title+"\n"+"NOcopies  :"+"    "+NOcopies);
                           	  textarea.setFont(textarea.getFont().deriveFont(20.0f) );    //font size

                        
    // for text null
              textISBN.setText("");
              textAuthor.setText("");
              textTitle.setText("");
              textPrice.setText("");
              textNOcopies.setText("");
			  
                // end text null
	   }
	 } //end if    
 } //end class action 1
//end class


//start class
 //class for search button
 class Search  implements  ActionListener{

	JFrame  frame2;
	
	// for ist frame
	Search(JFrame frame2)
	{
		this.frame2=frame2;
	}



   // for 2nd frame  implements
	 public void actionPerformed(ActionEvent ae)
       {
             JButton search=(JButton)ae.getSource();
			 String searchbutton=search.getText();
                    if(searchbutton=="Search ISBN")
	          			{
                          frame2.setVisible(false);     // c0lse frame
					   
					   
//frame 3
                 JFrame frame4=new JFrame ("BOOK SHELF");
   	             frame4.setLayout(null);
                 frame4.setSize(1200,652);
                 frame4.setExtendedState(JFrame.MAXIMIZED_BOTH);     // for full screen frame
	             frame4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    					   
	
  // make  a label    
      JLabel  label3=new  JLabel(" BOOK SHELF ");
      label3.setFont(label3.getFont().deriveFont(37.0f) );
	  label3.setForeground(Color.red);
      label3.setBounds(230, 0, 1200,50);  
	  frame4.add(label3);   // add in frame 

		
	// first
		//make a label of ist   
      JLabel  mobile=new  JLabel("ISBN");
      mobile.setFont(mobile.getFont().deriveFont(27.0f) );
      mobile.setBounds(180,150,330,30);
	  //Font design
	  frame4.add(mobile);   // add in frame 
	//Make a Textfield 1
     JTextField textmobile= new JTextField();
	 textmobile.setBounds(380,150,330,30);
     frame4.add(textmobile);

   
 
 
       //textarea
   JTextArea textarea=new JTextArea();
   textarea.setBounds(800,150,420,400);
    textarea.setEditable(false);   //for unedit textarea
    frame4.add(textarea);

 
  // make button for search the account
      JButton searchb = new JButton("SEARCH");
      searchb.setBounds(550,260,215,50);
	 searchb.addActionListener(new Action2(textmobile,textarea,searchb) );
	  frame4.add(searchb);
  
  

// make button for back the menu
      JButton back = new JButton("BACK");
      back.setBounds(250,260,170,50);
	  back.addActionListener(new Searc(frame2,frame4) );   //second and fourth frame
	  frame4.add(back);
	  
	  
  frame4.setVisible(true);
						}
	   }
 }






//start 
// for search button
// for back button implement
class Searc implements ActionListener{
          
		    JFrame frame2;
			JFrame frame4;
			
    Searc(JFrame frame2,JFrame frame4)
	 {
		this.frame2=frame2;
		this.frame4=frame4;
		
        }
	
		
 public void actionPerformed(ActionEvent ae)
       {
    JButton back=(JButton)ae.getSource();
  String temp=back.getText();
     if(temp=="BACK")
     {
		 frame4.setVisible(false);  //close third frame
	     frame2.setVisible(true);    //open second frame 	  
	   }
 		
	}
} 
//end class


//start class  
 //class for search button of data base
 class Action2  implements  ActionListener{

//fields
    JTextArea   textareab;     
	JTextField  textmobile;
    JButton searchb;

	//variables
	static Connection connection=null;
	static Statement statement=null;
	static ResultSet rs=null;
	

   Action2(JTextField  textmobile , JTextArea textarea , JButton searchb)
       {
		
		this.textmobile=textmobile;
		this.textareab=textarea;
		this.searchb=searchb;
		
		}
		
 public void actionPerformed(ActionEvent ae)
       {
		
		  
		   //convert text in to string
		     String tmobile=textmobile.getText();           
						int xz=Integer.parseInt(tmobile);
						long z=(int)xz;

						
			 //end coversion
			
			 JButton searchb=(JButton)ae.getSource();
			 String searchbutton=searchb.getText();

  
 
    boolean flag=true;
			
		     try{	
          	Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		    String db="Account.accdb";
			String dbURL="jdbc:ucanaccess://"+db;
			connection=DriverManager.getConnection(dbURL);
			statement=connection.createStatement();
			rs=statement.executeQuery("SELECT * FROM Account");
            	   if(searchbutton=="SEARCH")
					 while(rs.next()){
			  rs.getInt(1);        
			  rs.getInt(2);     
		      rs.getString(3);     
			  rs.getString(4);     
 		      rs.getString(5);     
              rs.getString(6);     
            
			 if(z==rs.getInt(2))
 		        {
					JOptionPane.showMessageDialog(searchb,"SEARCHING  FOUND");
					flag =false;
	textareab.setText("ID   :"+"    "+rs.getInt(1) +"\n"+"Author   :"+"    "+rs.getString(3) +"\n" +"Title  :"+"    "+rs.getString(4)+"\n"+"Price  :" +"    "+rs.getString(5)+"\n"+"NOcopies  :"+"    "+rs.getString(6)+"\n"+"MOBILE  :"+"    "+rs.getInt(2));        				
              textareab.setFont(textareab.getFont().deriveFont(20.0f) );    //font size                
				break;	
			} //end of if
			 }  // end of while
			
			
			
			if(flag){
				  JOptionPane.showMessageDialog(searchb,"NOT FOUND");
				textareab.setFont(textareab.getFont().deriveFont(20.0f) );    //font size
				textareab.setText("NOT FOUND");
				}
	
                                        System.out.println(" Transaction Successfully");             
	      } // end try
    
	catch(Exception dil)
         { 
       dil.printStackTrace();
           }   //end catch
		finally{
			try{
				if(null != connection)
				{
                    rs.close();
					statement.close();
					connection.close();
                    	} //if
			}  //end try
			catch(SQLException dil2)
                                             {
                                                 dil2.printStackTrace();
                                              } // end catch

		} //end finally

    // for text null
              textmobile.setText("");
                // end text null
	 
	// } //end if
    }
 } //end class action 1
//end class


    
  //Barrow Button
  //start class
 //class for modify button
 class Modify  implements  ActionListener{

	JFrame  frame2;
	
	// for ist frame
	Modify(JFrame frame2)
	{
		this.frame2=frame2;
	}

   
   // for 2nd frame  implements
	 public void actionPerformed(ActionEvent ae)
       {
             JButton create=(JButton)ae.getSource();
			 String createbutton=create.getText();
                    if(createbutton=="Barrow Books")
	          			{
                          frame2.setVisible(false);     // c0lse frame
					   
					   
//frame 6
                JFrame frame6=new JFrame ("Book Shelf");
   	             frame6.setLayout(null);
                 frame6.setSize(1200,652);
                 frame6.setExtendedState(JFrame.MAXIMIZED_BOTH);     // for full screen frame
	             frame6.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   
  // make  a label    
      JLabel  label3=new  JLabel(" BOOK SHELF ");
      label3.setFont(label3.getFont().deriveFont(37.0f) );
	  label3.setForeground(Color.red);
      label3.setBounds(230, 0, 1200,50);
      
	  //Font design
	  Font font10 = new Font("Cooper Black", Font.BOLD, 40);
	  label3.setFont(font10);   //set font 
	  frame6.add(label3);   // add in frame 


	  
	
	// first
		//make a label of ist   
      JLabel  ISBN=new  JLabel("ISBN");
      ISBN.setFont(ISBN.getFont().deriveFont(27.0f) );
      ISBN.setBounds(180,150,330,30);
	  frame6.add(ISBN);   // add in frame 
	//Make a Textfield 1
     JTextField textISBN= new JTextField();
	 textISBN.setBounds(380,150,330,30);
     frame6.add(textISBN);

   
   //2nd
		//make a label of 2nd   
      JLabel  CustomerName=new  JLabel("CusName");
      CustomerName.setFont(CustomerName.getFont().deriveFont(27.0f) );
      CustomerName.setBounds(180,220,330,30);
	  frame6.add(CustomerName);   // add in frame
	//Make a Textfield 2
     JTextField textCustomerName= new JTextField();
	 textCustomerName.setBounds(380,230,330,30);
     frame6.add(textCustomerName);
   
   
   //3rd
		//make a label of 3rd   
      JLabel  CustomerID=new  JLabel("CusID");
      CustomerID.setFont(CustomerID.getFont().deriveFont(27.0f) );
      CustomerID.setBounds(180,290,330,30);
	  //Font design
	  frame6.add(CustomerID);   // add in frame 
	//Make a Textfield 3
     JTextField textCustomerID= new JTextField();
	 textCustomerID.setBounds(380,290,330,30);
     frame6.add(textCustomerID);
   
 

 //4rd
		//make a label of 4rd   
      JLabel  Address=new  JLabel("Address");
      Address.setFont(Address.getFont().deriveFont(27.0f) );
      Address.setBounds(180,360,330,30);
	  frame6.add(Address);   // add in frame 
	//Make a Textfield 4
     JTextField textAddress= new JTextField();
	 textAddress.setBounds(380,360,330,30);
     frame6.add(textAddress);
   
 

   //5rd
		//make a label of 5rd   
      JLabel  Email=new  JLabel("Email");
      Email.setFont(Email.getFont().deriveFont(27.0f) );
      Email.setBounds(180,430,330,30);
	  frame6.add(Email);   // add in frame 
	//Make a Textfield 5
     JTextField textEmail= new JTextField();
	 textEmail.setBounds(380,430,330,30);
     frame6.add(textEmail);
    
	
 
      //textarea
   JTextArea textarea=new JTextArea();
   textarea.setBounds(800,150,420,400);
    textarea.setEditable(false);   //for unedit textarea
    frame6.add(textarea);
	
  
 
  // make button for save the account
      JButton save = new JButton("SAVE");
      save.setBounds(550,500,170,50);
	  //Font design
	  save.addActionListener(new actionBarrow(textISBN,textCustomerID,textCustomerName,textAddress,textEmail,textarea,save) );
	  frame6.add(save);
  
  

// make button for back the menu
      JButton back = new JButton("BACK");
      back.setBounds(250,500,170,50);
	  back.addActionListener(new CreatBarrow(frame2,frame6) );   //second and third frame
	  frame6.add(back);
	  

  frame6.setVisible(true);


	   }
 }  //end class   	   
 //end third frame          



//start
// for back button implement
class CreatBarrow implements ActionListener{
          
		    JFrame frame2;
			JFrame frame6;
			
    CreatBarrow(JFrame frame2,JFrame frame6)
	 {
		this.frame2=frame2;
		this.frame6=frame6;
		
        }
	
		
 public void actionPerformed(ActionEvent ae)
       {
    JButton back=(JButton)ae.getSource();
    String temp=back.getText();
     if(temp=="BACK")
     {
		 frame6.setVisible(false);  //close third frame
	     frame2.setVisible(true);    //open second frame 	  
	   }
 		
	}
} 
  

//start class  
 //class for create barrow of data base
 class actionBarrow  implements  ActionListener{

//fields
    JTextArea   textarea;     
	JTextField  textISBN;
	JTextField  textCustomerName;
    JTextField  textCustomerID;
    JTextField  textAddress;
    JTextField  textEmail;

 	JButton save;
	//variables
	static Connection connection=null;
	static Statement statement=null;
	static ResultSet resultSet=null;
	

   actionBarrow(JTextField  textISBN, JTextField  textCustomerName, JTextField  textCustomerID, JTextField  textAddress, JTextField  textEmail,JTextArea textarea,JButton save)
              
	 {
		this.textISBN=textISBN;
        this.textCustomerName=textCustomerName;
	    this.textCustomerID=textCustomerID;
	    this.textAddress=textAddress;
	    this.textEmail=textEmail;
		this.textarea=textarea;
		this.save=save;
		}
		
 public void actionPerformed(ActionEvent ae)
       {

		   Date date = new Date();
	  String tempdate=date + "";


		   //convert text in to string
		     String ISBN=textISBN.getText();
             String CustomerName=textCustomerName.getText();
             String CustomerID=textCustomerID.getText();
             String Address=textAddress.getText();
             String Email=textEmail.getText();
             
			 
			 int xz=Integer.parseInt(ISBN);
			 Long z=Long.valueOf(xz); 
		  
			
			 JButton save=(JButton)ae.getSource();
			 String createbutton=save.getText();

 

//connect to database for connection to create                   
				    if(createbutton=="SAVE")
	          			{
		     try{	
          	Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		  String db="Account.accdb";
			String dbURL="jdbc:ucanaccess://"+db;
			connection=DriverManager.getConnection(dbURL);
			statement=connection.createStatement();
			resultSet=statement.executeQuery("SELECT * FROM Barrow");
    int x=statement.executeUpdate("INSERT INTO Barrow VALUES(0,' "+z+" ',' "+CustomerName+" ',' "+CustomerID+" ',' "+Address+" ',' "+Email+" ',' "+tempdate+" ')");
   
	   if(x > 0)     
		{			
             JOptionPane.showMessageDialog(save,"Successfully Inserted.");
            System.out.println("Successfully Inserted");             
		}
        
		else            
			{
				                       JOptionPane.showMessageDialog(save,"Insert Failed.");
                System.out.println("Insert Failed."); 
			}
	      } // end try
    
	catch(Exception dil)
         { 
       dil.printStackTrace();
           }   //end catch
		finally{
			try{
				if(null != connection)
				{
                    resultSet.close();
					statement.close();
					connection.close();
                    	} //if
			}  //end try
			catch(SQLException dil2)
                                             {
                                                 dil2.printStackTrace();
                                              } // end catch

		} //end finally
		
						
// write in text
 textarea.setText("ISBN   :"+"    "+ISBN +"\n" +"CustomerName   :"+"    "+CustomerName+"\n"+"CustomerID   :" +"    "+CustomerID+"\n"+"Address  :"+"    "+Address+"\n"+"Email  :"+"    "+Email);
                           	  textarea.setFont(textarea.getFont().deriveFont(20.0f) );    //font size

                        
    // for text null
              textISBN.setText("");
              textCustomerName.setText("");
              textCustomerID.setText("");
              textAddress.setText("");
              textEmail.setText("");
			  
                // end text null
	 
	 } //end if
    }
 } //end class action 1
//end class





 } 
//end class










  



//searchAuthor





//start class
 //class for search button
 class SearchAuthor  implements  ActionListener{

	JFrame  frame2;
	
	// for ist frame
	SearchAuthor(JFrame frame2)
	{
		this.frame2=frame2;
	}



   // for 2nd frame  implements
	 public void actionPerformed(ActionEvent ae)
       {
             JButton search=(JButton)ae.getSource();
			 String searchbutton=search.getText();
                    if(searchbutton=="Search Author")
	          			{
                          frame2.setVisible(false);     // c0lse frame
					   
					   
//frame 3
                 JFrame frame4=new JFrame ("BOOK SHELF");
   	             frame4.setLayout(null);
                 frame4.setSize(1200,652);
                 frame4.setExtendedState(JFrame.MAXIMIZED_BOTH);     // for full screen frame
	             frame4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    

  // make  a label    
      JLabel  label3=new  JLabel(" BOOK SHELF ");
      label3.setFont(label3.getFont().deriveFont(37.0f) );
	  label3.setForeground(Color.red);
      label3.setBounds(230, 0, 1200,50);
       frame4.add(label3);   // add in frame 


	
	
	
	// first
		//make a label of ist   
      JLabel  mobile=new  JLabel("Author");
      mobile.setFont(mobile.getFont().deriveFont(27.0f) );
      mobile.setBounds(180,150,330,30);
	  frame4.add(mobile);   // add in frame 
	//Make a Textfield 1
     JTextField textmobile= new JTextField();
	 textmobile.setBounds(380,150,330,30);
     frame4.add(textmobile);

   
 
 
       //textarea
   JTextArea textarea=new JTextArea();
   textarea.setBounds(800,150,420,400);
    textarea.setEditable(false);   //for unedit textarea
    frame4.add(textarea);

 
  // make button for search the account
      JButton searchb = new JButton("SEARCH");
      searchb.setBounds(550,260,215,50);
	  
	  //Font design
	  searchb.addActionListener(new Action3(textmobile,textarea,searchb) );
	  frame4.add(searchb);
  
  

// make button for back the menu
      JButton back = new JButton("BACK");
      back.setBounds(250,260,170,50);
	  back.addActionListener(new Searc3(frame2,frame4) );   //second and fourth frame
	  frame4.add(back);
	  
	  
  frame4.setVisible(true);
						}
	   }
 }






//start 
// for search button
// for back button implement
class Searc3 implements ActionListener{
          
		    JFrame frame2;
			JFrame frame4;
			
    Searc3(JFrame frame2,JFrame frame4)
	 {
		this.frame2=frame2;
		this.frame4=frame4;
		
        }
	
		
 public void actionPerformed(ActionEvent ae)
       {
    JButton back=(JButton)ae.getSource();
  String temp=back.getText();
     if(temp=="BACK")
     {
		 frame4.setVisible(false);  //close third frame
	     frame2.setVisible(true);    //open second frame 	  
	   }
 		
	}
} 
//end class


//start class  
 //class for search button of data base
 class Action3  implements  ActionListener{

//fields
    JTextArea   textareab;     
	JTextField  textmobile;
    JButton searchb;

	//variables
	static Connection connection=null;
	static Statement statement=null;
	static ResultSet rs=null;
	

   Action3(JTextField  textmobile , JTextArea textarea , JButton searchb)
       {
		
		this.textmobile=textmobile;
		this.textareab=textarea;
		this.searchb=searchb;
		
		}
		
 public void actionPerformed(ActionEvent ae)
       {
		   
		   //convert text in to string
		     String tmobile=textmobile.getText();           
					
						
			 //end coversion
			
			 JButton searchb=(JButton)ae.getSource();
			 String searchbutton=searchb.getText();

  
 
    boolean flag=true;
			
		     try{	
          	Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		    String db="Account.accdb";
			String dbURL="jdbc:ucanaccess://"+db;
			connection=DriverManager.getConnection(dbURL);
			statement=connection.createStatement();
			rs=statement.executeQuery("SELECT * FROM Account");
            	   if(searchbutton=="SEARCH")
					 while(rs.next()){
			  rs.getInt(1);        
			  rs.getInt(2);     
		      rs.getString(3);     
			  rs.getString(4);     
 		      rs.getString(5);     
              rs.getString(6);     
            
			 if(tmobile.equals(rs.getString(3)))
 		        {
					JOptionPane.showMessageDialog(searchb,"SEARCHING  FOUND");
					flag =false;
	textareab.setText("ID   :"+"    "+rs.getInt(1) +"\n"+"Author   :"+"    "+rs.getString(3) +"\n" +"Title  :"+"    "+rs.getString(4)+"\n"+"Price  :" +"    "+rs.getString(5)+"\n"+"NOcopies  :"+"    "+rs.getString(6)+"\n"+"MOBILE  :"+"    "+rs.getInt(2));        				
              textareab.setFont(textareab.getFont().deriveFont(20.0f) );    //font size                
				break;	
			} //end of if
			 }  // end of while
			
			
			
			if(flag){
				  JOptionPane.showMessageDialog(searchb,"NOT FOUND");
				textareab.setFont(textareab.getFont().deriveFont(20.0f) );    //font size
				textareab.setText("NOT FOUND");
				}
	
                                        System.out.println(" Transaction Successfully");             
	      } // end try
    
	catch(Exception dil)
         { 
       dil.printStackTrace();
           }   //end catch
		finally{
			try{
				if(null != connection)
				{
                    rs.close();
					statement.close();
					connection.close();
                    	} //if
			}  //end try
			catch(SQLException dil2)
                                             {
                                                 dil2.printStackTrace();
                                              } // end catch

		} //end finally

    // for text null
              textmobile.setText("");
                // end text null
	 
	// } //end if
    }
 } //end class action 1
//end class













//search title


//start class
 //class for search button
 class SearchTitle  implements  ActionListener{

	JFrame  frame2;
	
	// for ist frame
	SearchTitle(JFrame frame2)
	{
		this.frame2=frame2;
	}



   // for 2nd frame  implements
	 public void actionPerformed(ActionEvent ae)
       {
             JButton search=(JButton)ae.getSource();
			 String searchbutton=search.getText();
                   if(searchbutton=="Search Title")
	          			{
                          frame2.setVisible(false);     // c0lse frame
					   
					   
//frame 3
                 JFrame frame4=new JFrame ("BOOK SHELF");
   	             frame4.setLayout(null);
                 frame4.setSize(1200,652);
                 frame4.setExtendedState(JFrame.MAXIMIZED_BOTH);     // for full screen frame
	             frame4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
             

  // make  a label    
      JLabel  label3=new  JLabel(" BOOK SHELF ");
      label3.setFont(label3.getFont().deriveFont(37.0f) );
	  label3.setForeground(Color.red);
      label3.setBounds(230, 0, 1200,50);
      
	  //Font design
	  Font font10 = new Font("Cooper Black", Font.BOLD, 40);
	  label3.setFont(font10);   //set font 
	  frame4.add(label3);   // add in frame 


	 
	
	
	
	// first
		//make a label of ist   
      JLabel  mobile=new  JLabel("Title");
      mobile.setFont(mobile.getFont().deriveFont(27.0f) );
      mobile.setBounds(180,150,330,30);
	  frame4.add(mobile);   // add in frame 
	//Make a Textfield 1
     JTextField textmobile= new JTextField();
	 textmobile.setBounds(380,150,330,30);
     frame4.add(textmobile);

   
 
 
       //textarea
   JTextArea textarea=new JTextArea();
   textarea.setBounds(800,150,420,400);
    textarea.setEditable(false);   //for unedit textarea
    frame4.add(textarea);

 
  // make button for search the account
      JButton searchb = new JButton("SEARCH");
      searchb.setBounds(550,260,215,50);
	 
      searchb.addActionListener(new Action4(textmobile,textarea,searchb) );
	  frame4.add(searchb);
  
  

// make button for back the menu
      JButton back = new JButton("BACK");
      back.setBounds(250,260,170,50);
	  back.addActionListener(new Searc4(frame2,frame4) );   //second and fourth frame
	 
	  frame4.add(back);
	  
	  
  frame4.setVisible(true);
						}
	   }
 }






//start 
// for search button
// for back button implement
class Searc4 implements ActionListener{
          
		    JFrame frame2;
			JFrame frame4;
			
    Searc4(JFrame frame2,JFrame frame4)
	 {
		this.frame2=frame2;
		this.frame4=frame4;
		
        }
	
		
 public void actionPerformed(ActionEvent ae)
       {
    JButton back=(JButton)ae.getSource();
  String temp=back.getText();
     if(temp=="BACK")
     {
		 frame4.setVisible(false);  //close third frame
	     frame2.setVisible(true);    //open second frame 	  
	   }
 		
	}
} 
//end class


//start class  
 //class for search button of data base
 class Action4  implements  ActionListener{

//fields
    JTextArea   textareab;     
	JTextField  textmobile;
    JButton searchb;

	//variables
	static Connection connection=null;
	static Statement statement=null;
	static ResultSet rs=null;
	

   Action4(JTextField  textmobile , JTextArea textarea , JButton searchb)
       {
		
		this.textmobile=textmobile;
		this.textareab=textarea;
		this.searchb=searchb;
		
		}
		
 public void actionPerformed(ActionEvent ae)
       {
		   
		   //convert text in to string
		     String tmobile=textmobile.getText();           
					
						
			 //end coversion
			
			 JButton searchb=(JButton)ae.getSource();
			 String searchbutton=searchb.getText();

  
 
    boolean flag=true;
			
		     try{	
          	Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		    String db="Account.accdb";
			String dbURL="jdbc:ucanaccess://"+db;
			connection=DriverManager.getConnection(dbURL);
			statement=connection.createStatement();
			rs=statement.executeQuery("SELECT * FROM Account");
            	   if(searchbutton=="SEARCH")
					 while(rs.next()){
			  rs.getInt(1);        
			  rs.getInt(2);     
		      rs.getString(3);     
			  rs.getString(4);     
 		      rs.getString(5);     
              rs.getString(6);     
            
			 if(tmobile.equals(rs.getString(4)))
 		        {
					JOptionPane.showMessageDialog(searchb,"SEARCHING  FOUND");
					flag =false;
	textareab.setText("ID   :"+"    "+rs.getInt(1) +"\n"+"Author   :"+"    "+rs.getString(3) +"\n" +"Title  :"+"    "+rs.getString(4)+"\n"+"Price  :" +"    "+rs.getString(5)+"\n"+"NOcopies  :"+"    "+rs.getString(6)+"\n"+"MOBILE  :"+"    "+rs.getInt(2));        				
              textareab.setFont(textareab.getFont().deriveFont(20.0f) );    //font size                
				break;	
			} //end of if
			 }  // end of while
			
			
			
			if(flag){
				  JOptionPane.showMessageDialog(searchb,"NOT FOUND");
				textareab.setFont(textareab.getFont().deriveFont(20.0f) );    //font size
				textareab.setText("NOT FOUND");
				}
	
                                        System.out.println(" Transaction Successfully");             
	      } // end try
    
	catch(Exception dil)
         { 
       dil.printStackTrace();
           }   //end catch
		finally{
			try{
				if(null != connection)
				{
                    rs.close();
					statement.close();
					connection.close();
                    	} //if
			}  //end try
			catch(SQLException dil2)
                                             {
                                                 dil2.printStackTrace();
                                              } // end catch

		} //end finally

    // for text null
              textmobile.setText("");
                // end text null
	 
	// } //end if
    }
 } //end class action 1
//end class













//start class
 //class for search button
 class BookListing  implements  ActionListener{

	JFrame  frame2;
	
	// for ist frame
	BookListing(JFrame frame2)
	{
		this.frame2=frame2;
	}



	//variables
	static Connection connection=null;
	static Statement statement=null;
	static ResultSet rs=null;
   // for 2nd frame  implements
	 public void actionPerformed(ActionEvent ae)
       {
             JButton search=(JButton)ae.getSource();
			 String searchbutton=search.getText();
                   if(searchbutton=="Book Listing")
	          			{
                          frame2.setVisible(false);     // c0lse frame
					  

					   
//frame 5
                 JFrame frame5=new JFrame ("BOOK SHELF");
   	             frame5.setLayout(null);
                 frame5.setSize(1200,652);
                 frame5.setExtendedState(JFrame.MAXIMIZED_BOTH);     // for full screen frame
	             frame5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
             

  // make  a label    
      JLabel  label3=new  JLabel(" BOOK SHELF ");
      label3.setFont(label3.getFont().deriveFont(37.0f) );
	  label3.setForeground(Color.red);
      label3.setBounds(230, 0, 1200,50);
      
	  //Font design
	  Font font10 = new Font("Cooper Black", Font.BOLD, 40);
	  label3.setFont(font10);   //set font 
	  frame5.add(label3);   // add in frame 
					  
 
  // make button for search the account
      JButton searchb = new JButton("FETCH");
      searchb.setBounds(550,260,215,50);
	 
      searchb.addActionListener(new Action5(frame5) );
	  frame5.add(searchb);

					  
// make button for back the menu
      JButton back = new JButton("BACK");
      back.setBounds(250,260,170,50);
	  back.addActionListener(new Searc4(frame2,frame5) );   //second and fifth frame
	  frame5.add(back);
	  
  frame5.setVisible(true);
						}
	   }
 }



class Action5  implements  ActionListener{

//fields
    JFrame frame5;

	//variables
	static Connection connection=null;
	static Statement statement=null;
	static ResultSet rs=null;
	

   Action5(JFrame frame5)
       {
		
		this.frame5=frame5;
		
		}
		
 public void actionPerformed(ActionEvent ae)
       {
		   
						
			 //end coversion
			
			 JButton searchb=(JButton)ae.getSource();
			 String searchbutton=searchb.getText();

  JFrame frame6 = new JFrame("Database Search Result");
frame6.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
frame6.setLayout(new BorderLayout());

 String[] columnNames = {"ID", "ISBN", "Author", "Title","Price","NOcopies","CustomerName","CustomerID"};
    boolean flag=true;
			
		DefaultTableModel model = new DefaultTableModel();
model.setColumnIdentifiers(columnNames);
JTable table = new JTable();
table.setModel(model); 
table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
table.setFillsViewportHeight(true);
JScrollPane scroll = new JScrollPane(table);
scroll.setHorizontalScrollBarPolicy(
JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
scroll.setVerticalScrollBarPolicy(
JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED); 
String Author= "";
String Title= "";
String Price = "";
String NOcopies = "";
String CustomerName="";
String CustomerID="";

int ID;
int ISBN;
int i =0;
			
		     try{	
          	Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		    String db="Account.accdb";
			String dbURL="jdbc:ucanaccess://"+db;
			connection=DriverManager.getConnection(dbURL);
			statement=connection.createStatement();
			rs=statement.executeQuery("SELECT * FROM Account,Barrow WHERE Account.ISBN =Barrow.ISBN;  ");
            	   if(searchbutton=="FETCH")		   
while(rs.next())
{
ID = rs.getInt("ID");
ISBN = rs.getInt("ISBN");
Author = rs.getString("Author");
Title = rs.getString("Title");
Price= rs.getString("Price");
NOcopies = rs.getString("NOcopies");
CustomerName = rs.getString("CustomerName");
CustomerID= rs.getString("CustomerID");
model.addRow(new Object[]{ID,ISBN,Author,Title,Price,NOcopies,CustomerName,CustomerID});
i++;
}
if(i <1)
{
JOptionPane.showMessageDialog(null, "No Record Found","Error",
JOptionPane.ERROR_MESSAGE);
}
else
{
System.out.println(i+" Records Found");
}
}
catch(Exception ex)
{
JOptionPane.showMessageDialog(null, ex.getMessage(),"Error",
JOptionPane.ERROR_MESSAGE);
}
frame6.add(scroll);
	frame6.setVisible(true);
frame6.setSize(600,600);
				
				
 }
 } //end class action 1
//end class
